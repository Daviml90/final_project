//
//  Menu.swift
//  Little Lemon
//
//  Created by Davi Martinelli de Lira on 1/22/24.
//

import SwiftUI

struct Menu: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    
    
    func buildSortDescriptors() -> [NSSortDescriptor] {
        return [NSSortDescriptor(key: "title", ascending: true, selector: #selector(NSString.localizedStandardCompare))]
    }
    func buildPredicate() -> NSPredicate {
        if searchText.isEmpty {
            return NSPredicate(value: true)
        } else {
            return NSPredicate(format: "title CONTAINS[cd] %@", searchText)
        }
    }
    
    @State var starters: Bool = false
    @State var mains: Bool = false
    @State var desserts: Bool = false
    @State var drinks: Bool = false
    
    var buildCompound: NSCompoundPredicate {
        let searchPredicate = buildPredicate()
        let startersPredicate = starters ? NSPredicate(format: "category CONTAINS[cd] %@", "starters") : NSPredicate(value: true)
        let mainsPredicate = mains ? NSPredicate(format: "category CONTAINS[cd] %@", "mains") : NSPredicate(value: true)
        let dessertsPredicate = desserts ? NSPredicate(format: "category CONTAINS[cd] %@", "desserts") : NSPredicate(value: true)
        let drinksPredicate = drinks ? NSPredicate(format: "category CONTAINS[cd] %@", "drinks") : NSPredicate(value: true)
    
    return NSCompoundPredicate(type: .and, subpredicates: [searchPredicate, startersPredicate, mainsPredicate, dessertsPredicate, drinksPredicate])
    }
    
    @State var searchText = ""
    
    var body: some View {
        
        NavigationView {
            VStack {
                ZStack {
                    VStack() {
                        Image(systemName: "person.crop.circle")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.lemonGreen)
                    }.frame(maxWidth: .infinity, alignment: .trailing)
                        .padding(.horizontal)
                    Image("littleLemonLogo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 50)
                }
                
                VStack {
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Little Lemon")
                                .font(.largeTitle)
                            Text("Chicago")
                                .font(.title)
                            Text("We are a family owned Mediterranean restaurant, focused on traditional recipes served with a modern twist")
                        }
                        .padding()
                        Image("home-pic")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 120
                            )

                    }
                    TextField("Search Menu", text: $searchText)
                        .foregroundColor(.lemonGreen)
                        .font(.headline)
                        .padding(4)
                        .background(RoundedRectangle(cornerRadius: 25.0)
                            .fill(.white))
                        .padding()
                }
                .foregroundColor(.white)
                .background(.lemonGreen)
                
                VStack(alignment: .leading) {
                    Text("ORDER FOR DELIVERY")
                        .bold()
                    HStack {
                       categoryButton(title: "Starters", bool: $starters)
                        categoryButton(title: "Mains", bool: $mains)
                        categoryButton(title: "Desserts", bool: $desserts)
                        categoryButton(title: "drinks", bool: $drinks)
                    }
                    Rectangle()
                        .fill(.lemonGray)
                        .frame(maxWidth: .infinity, maxHeight: 2)
                }.frame(maxWidth: .infinity)
                    .padding(.horizontal)
                    
                
        
                FetchedObjects(predicate: buildCompound, sortDescriptors: buildSortDescriptors()) { (dishes: [Dish]) in
                        List(dishes) { dish in
                            dishLayout(dish: dish.title, price: dish.price, description: dish.dishDescription, image: dish.image)
                        }
                        .listStyle(.plain)
                    }
             }
            .onAppear(perform: {
                
                getMenuData()
            })
        }
    }
    
    @ViewBuilder
    func dishLayout(dish: String?, price: String?, description: String?, image: String?) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text(dish ?? "dish")
                    .bold()
                    .foregroundColor(.black)
                Text(description ?? "description")
                Text("$\(price ?? "0")")
                    .bold()
            }
            .foregroundColor(.lemonGreen)
            .font(.subheadline)
            .padding()
            Spacer()
            AsyncImage(url: URL(string: image!), content: { image in
                                image.resizable()
                                     .aspectRatio(contentMode: .fit)
                                     .frame(maxWidth: 70, maxHeight: 50)
                            },
                            placeholder: {
                                ProgressView()
                            }
                        )

        }
    }
    
    
    
    @ViewBuilder
    func categoryButton(title: String, bool: Binding<Bool>) -> some View {
        Button(action: {bool.wrappedValue.toggle()}, label: {
            Text(title)
                .bold()
                .foregroundColor(bool.wrappedValue ? .lemonGray : .lemonGreen)
                .padding(10)
                .background(RoundedRectangle(cornerRadius: 15)
                    .fill(bool.wrappedValue ? .lemonGreen : .lemonGray))
        })
    }
    
    func getMenuData() {
        PersistenceController.shared.clear("Dish")
        
        let littleLemonAddress = "https://raw.githubusercontent.com/Meta-Mobile-Developer-PC/Working-With-Data-API/main/menu.json"
        let url = URL(string: littleLemonAddress)
        if let url = url {
            let request = URLRequest(url: url)
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                if let data = data{
                    let fullMenu = try? JSONDecoder().decode(MenuList.self, from: data)
                    guard let fullMenu = fullMenu else {
                        return print("test2")
                    }
                    for item in fullMenu.menu {
                        let dish = Dish(context: viewContext)
                        dish.image = item.image
                        dish.price = item.price
                        dish.title = item.title
                        dish.category = item.category
                        dish.dishDescription = item.description
                    }
                    try? viewContext.save()
                }
            }
            task.resume()
        }
        
    }
}

#Preview {
    Menu()
}
