//
//  UserProfile.swift
//  Little Lemon
//
//  Created by Davi Martinelli de Lira on 1/22/24.
//

import SwiftUI

struct UserProfile: View {
    @ObservedObject var model: Model
    
    var body: some View {
        VStack {
            ZStack {
                VStack() {
                    Image(systemName: "person.crop.circle")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .foregroundColor(.lemonGreen)
                }.frame(maxWidth: .infinity, alignment: .trailing)
                    .padding(.horizontal)
                Image("littleLemonLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 50)
            }
            
            VStack(alignment: .leading, spacing: 10) {
                Text("Personal information")
                    .font(.title)
                    .bold()
                Text("Avatar")
                Image(systemName: "person.crop.circle")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 70, height: 70)
                Text("First Name:")
                Text(UserDefaults.standard.string(forKey: kFirstName) ?? "")
                    .font(.title)
                Text("Last Name:")
                Text(UserDefaults.standard.string(forKey: kLastName) ?? "")
                    .font(.title)
                Text("Email:")
                Text(UserDefaults.standard.string(forKey: kEmail) ?? "")
                    .font(.title)
                
                Button(action: {UserDefaults.standard.setValue(false, forKey: kIsLoggedIn)
                    model.isLoggedIn = false}, label: {
                        Text("Logout")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical,8)
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding(2)
                            .background(RoundedRectangle(cornerRadius: 5)
                                .fill(.lemonYellow)
                                )
                })
                .padding(.top,10)
            }
            .padding()
            .background(RoundedRectangle(cornerRadius: 5)
                .stroke()
                .foregroundColor(.lemonGray))
            .padding()
            
            Spacer()
        }
        
    }
}

