//
//  Onboarding.swift
//  Little Lemon
//
//  Created by Davi Martinelli de Lira on 1/22/24.
//

import SwiftUI

let kFirstName = "first name key"
let kLastName = "last name key"
let kEmail = "email key"
let kIsLoggedIn = "kIsLoggedIn"

class Model: ObservableObject {
    @Published var isLoggedIn: Bool = UserDefaults.standard.bool(forKey: kIsLoggedIn)
}

struct Onboarding: View {
    @State var firstName: String = ""
    @State var lastName: String = ""
    @State var email: String = ""
    @StateObject var model = Model()
    
    var body: some View {
        NavigationStack {
            if model.isLoggedIn {
                Home(model: model)
            } else {
                    ZStack {
                        Image("littleLemonLogo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 50)
                    }
                    
                    VStack {
                        HStack {
                            VStack(alignment: .leading) {
                                Text("Little Lemon")
                                    .font(.largeTitle)
                                Text("Chicago")
                                    .font(.title)
                                Text("We are a family owned Mediterranean restaurant, focused on traditional recipes served with a modern twist")
                            }
                            .padding()
                            Image("home-pic")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 150, height: 120
                                )
                        }
                        }
                    
                    .foregroundColor(.white)
                    .background(.lemonGreen)
                VStack(alignment: .leading) {
                    Text("First Name*")
                    TextField("Type here...", text: $firstName)
                    Text("Last Name*")
                    TextField("Type here...", text: $lastName)
                    Text("Email*")
                    TextField("Type here...", text: $email)
                    
                }
                .padding(20)
                Button(action: {
                    if !firstName.isEmpty && !email.isEmpty && !kLastName.isEmpty{
                        UserDefaults.standard.set(firstName, forKey: kFirstName)
                        UserDefaults.standard.set(kLastName, forKey: kLastName)
                        UserDefaults.standard.set(email, forKey: kEmail)
                        UserDefaults.standard.setValue(true, forKey: kIsLoggedIn)
                        model.isLoggedIn = true
                    }
                }, label: {
                    Text("Register")
                        .font(.headline)
                        .foregroundColor(.lemonGray)
                        .padding(5)
                        .padding(.horizontal)
                        .background(RoundedRectangle(cornerRadius: 5)
                            .fill(.lemonGreen))
                })
                Spacer()
            }
        }
    }
}

#Preview {
    Onboarding()
}
