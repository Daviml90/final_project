//
//  MenuItem.swift
//  Little Lemon
//
//  Created by Davi Martinelli de Lira on 1/22/24.
//

import Foundation

struct MenuItem: Codable, Identifiable {
    var id: Int
    let title: String
    let price: String
    let image: String
    var description: String
    let category: String
}
