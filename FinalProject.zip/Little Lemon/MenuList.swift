//
//  MenuList.swift
//  Little Lemon
//
//  Created by Davi Martinelli de Lira on 1/22/24.
//

import Foundation

struct MenuList: Codable {
    let menu: [MenuItem]
}


